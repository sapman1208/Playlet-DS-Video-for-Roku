' This method is auto-generated!
function InitializeBindings()
    m.top.bindings = {
        fields: {
            "navBar": "/NavBar", 
            "invidious": "/Invidious", 
            "preferences": "/Preferences",
            "profilesService": "/ProfilesService"
        },
        childProps: {
    
        }
    }
end function