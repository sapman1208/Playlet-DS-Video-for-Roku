'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function HomeScreenUtils_GetFeed(feedFileName as string, preferences as object) as object
    feed = StringUtils_ParseJsonSafe(ReadAsciiFile(feedFileName))
    for each item in feed
        item.title = Tr(item.title)
        for each feedSource in item.feedSources
            feedSource.title = Tr(feedSource.title)
        end for
    end for
    if preferences = invalid then return feed
    homeLayout = preferences["misc.home_screen_layout"]
    if not IsArray(homeLayout) or homeLayout.Count() = 0
        return feed
    end if
    feedItems = {}
    for each item in feed
        feedItems[item["id"]] = item
    end for
    
    filteredFeed = []
    seenIds = {}
    for each item in homeLayout
        if IsAssociativeArray(item) and IsString(item.id)
            seenIds[item.id] = true
            if item.enabled = true and feedItems[item.id] <> invalid
                filteredFeed.push(feedItems[item.id])
            end if
        end if
    end for
    for each item in feed
        if not seenIds.DoesExist(item["id"])
            filteredFeed.push(item)
        end if
    end for
    return filteredFeed
end function