'import "HomeScreenUtils.bs"
'import "pkg:/components/ContextMenu/ContextMenuUtils.bs"
'import "pkg:/components/Navigation/Navigation.bs"
'import "pkg:/source/utils/FocusManagement.bs"
'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/RemoteKeys.bs"

function Init()
    InitializeBindings() ' auto-generated!
    m.top.focusable = true
    m.rowList = m.top.FindNode("rowList")
    m.rowList.screen = m.top
end function

function OnNodeReady()
    SetNavigation(invalid, "back", m.navBar)
    SetNavigation(invalid, "left", m.navBar)
    m.rowList.callfunc("BindNode", invalid)
    
    m.isRecommendation = m.top.feedFile = "libpkg:/config/shorts_layout.json" or m.top.feedFile = "libpkg:/config/music_layout.json"
    if m.isRecommendation
        m.rowList.observeField("someContentReady", "onRecommendationContent")
    end if
    if m.top.requiresProfile
        m.profilesService.observeFieldScoped("currentProfileChanged", FuncName(OnHomeLayoutChange))
    end if
    if not m.top.isDestination
        m.preferences.observeFieldScoped("misc.home_screen_layout", FuncName(OnHomeLayoutChange))
    end if
    OnHomeLayoutChange()
end function

function OnHomeLayoutChange() as void
    profile = m.profilesService.currentProfile
    needsSignIn = m.top.requiresProfile and profile = invalid
    prompt = m.top.findNode("profilePrompt")
    if m.isRecommendation
        if profile <> invalid and profile.type <> "youtube" then needsSignIn = true
        prompt.text = "Choose a YouTube account in Profile to see your recommendations."
    end if
    prompt.visible = needsSignIn
    m.rowList.visible = not needsSignIn
    m.top.focusable = not needsSignIn
    if needsSignIn
        m.rowList.feeds = invalid
        return
    end if
    preferences = m.preferences
    if m.top.isDestination then preferences = invalid
    m.rowList.feeds = HomeScreenUtils_GetFeed(m.top.feedFile, preferences)
end function

sub onRecommendationContent(event as object)
    if not m.rowList.visible then return
    prompt = m.top.findNode("profilePrompt")
    prompt.text = "YouTube has no recommendations for this tab right now."
    if event.getData()
        prompt.visible = false
        return
    end if
    if m.rowList.content = invalid then return
    for each row in m.rowList.content.getChildren(-1, 0)
        if row.getChildCount() > 0 or row.loadState <> "Loaded" then return
    end for
    prompt.visible = true
end sub

function OnFocusChange() as void
    if not m.top.focus
        return
    end if
    NodeSetFocus(m.rowList, true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    if NavigationKeyHandler(key, press).handled
        return true
    end if
    return false
end function

function GetContextMenuOptionsForItem(_rowItem as object) as object
    label = Tr("Refresh Home")
    if m.top.isDestination then label = "Refresh"
    refresh = ContextMenuUtils_CreateOption(label, m.rowList, "Refresh", [
        invalid
    ])
    return [
        refresh
    ]
end function