sub ExecuteJob()
    input = JobGetInput()
    action = input.action
    cancellation = JobGetCancellation()
    options = { cancellation: cancellation }
    if input.profile <> invalid and input.profile.type = "youtube"
        auth = ProfileContentAuthTokenUtils_EnsureFreshAccessToken(input.profile)
        if auth.state = "Ok"
            options.accessToken = auth.token
            options.onBehalfOfUser = auth.activeIdentifyToken
        end if
    end if
    if action = "details"
        JobSuccessData(OverlayFetchDetails(input, options))
    else if action = "comments"
        result = OverlayFetchComments(input, options)
        if result.error <> invalid
            JobError(result.error)
        else
            JobSuccessData(result)
        end if
    else
        if options.accessToken = invalid
            JobError("Sign in to YouTube from Profile to use this control.")
            return
        end if
        if action = "subscribe"
            result = InnertubeService_SubscribeToChannel(input.channelId, options)
        else if action = "unsubscribe"
            result = InnertubeService_UnsubscribeFromChannel(input.channelId, options)
        else
            result = OverlayRateVideo(action, input.videoId, options)
        end if
        if result.success
            JobSuccessData({action: action})
        else
            JobError("YouTube could not complete this action. Try again.")
        end if
    end if
end sub

function OverlayFetchDetails(input as object, options as object) as object
    details = {}
    request = Innertube_CreateNextRequest({videoId: input.videoId})
    request.Cancellation(options.cancellation)
    response = request.Await()
    if response.IsSuccess()
        data = response.Json()
        owner = OverlayFindNode(data, "videoOwnerRenderer")
        if owner <> invalid
            details.avatar = ValidString(ObjectUtils_Dig(owner, ["thumbnail", "thumbnails", 0, "url"]))
        end if
        renderer = OverlayFindNode(data, "videoSecondaryInfoRenderer")
        if renderer <> invalid
            details.description = Innertube_ParseText(renderer.description)
        end if
        if StringUtils_IsNullOrEmpty(details.description)
            renderer = OverlayFindNode(data, "expandableVideoDescriptionBodyRenderer")
            if renderer <> invalid
                details.description = ValidString(ObjectUtils_Dig(renderer, ["attributedDescriptionBodyText", "content"]))
            end if
        end if
        details.commentToken = OverlayCommentToken(data)
    end if
    if not input.hasDescription and StringUtils_IsNullOrEmpty(details.description)
        details.description = OverlayPublicDescription(input.videoId, options.cancellation)
    end if
    if input.channelId <> "" and StringUtils_IsNullOrEmpty(details.avatar)
        channel = InnertubeService_GetChannel(input.channelId, {cancellation: options.cancellation})
        if channel <> invalid and IsArray(channel.authorThumbnails) and channel.authorThumbnails.count() > 0
            details.avatar = ValidString(channel.authorThumbnails[0].url)
        end if
    end if
    if options.accessToken <> invalid
        request = OverlayTvRequest("next", {videoId: input.videoId}, options)
        response = request.Await()
        if response.IsSuccess()
            data = response.Json()
            rating = OverlayFindNode(data, "likeButtonRenderer")
            if rating <> invalid
                details.rating = LCase(ValidString(rating.likeStatus))
            else
                segmented = OverlayFindNode(data, "segmentedLikeDislikeButtonRenderer")
                if segmented <> invalid
                    if ObjectUtils_Dig(segmented, ["likeButton", "toggleButtonRenderer", "isToggled"]) = true
                        details.rating = "like"
                    else if ObjectUtils_Dig(segmented, ["dislikeButton", "toggleButtonRenderer", "isToggled"]) = true
                        details.rating = "dislike"
                    end if
                end if
            end if
            subscribe = OverlayFindNode(data, "subscribeButtonRenderer")
            if subscribe <> invalid and IsBool(subscribe.subscribed)
                details.subscribed = subscribe.subscribed
            end if
        end if
        if input.channelId <> "" and details.subscribed = invalid
            status = InnertubeService_GetSubscriptionStatusForChannel(input.channelId, options)
            if status.success then details.subscribed = status.isSubscribed
        end if
    end if
    return details
end function

function OverlayTvRequest(endpoint as string, body as object, options as object) as object
    body.context = Innertube_CreateContext("TV", CreateObject("roDeviceInfo"), options)
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/" + endpoint + "?prettyPrint=false&alt=json").JsonBody(body)
    request.Headers(Innertube_CreateHeaders("TV"))
    request.Header("Authorization", "Bearer " + options.accessToken)
    request.Cancellation(options.cancellation)
    return request
end function

function OverlayRateVideo(action as string, videoId as string, options as object) as object
    if action <> "like" and action <> "dislike" and action <> "removelike" then return {success: false}
    request = OverlayTvRequest("like/" + action, {target: {videoId: videoId}}, options)
    response = request.Await()
    if not response.IsSuccess() then return {success: false}
    data = response.Json()
    if not IsAssociativeArray(data) or data.error <> invalid then return {success: false}
    return {success: Innertube_ParseResponseDataForError(data) = ""}
end function

function OverlayFetchComments(input as object, options as object) as object
    token = ValidString(input.token)
    if token = "" then token = OverlayInitialCommentsToken(input.videoId)
    request = Innertube_CreateNextRequest({continuation: token})
    request.Cancellation(options.cancellation)
    response = request.Await()
    if not response.IsSuccess() then return {error: "YouTube comments could not be loaded."}
    data = response.Json()
    if not IsAssociativeArray(data) then return {error: "YouTube returned an unreadable comments page."}
    items = []
    mutations = ObjectUtils_Dig(data, ["frameworkUpdates", "entityBatchUpdate", "mutations"])
    if IsArray(mutations)
        for each mutation in mutations
            comment = ObjectUtils_Dig(mutation, ["payload", "commentEntityPayload"])
            if comment <> invalid
                content = ValidString(ObjectUtils_Dig(comment, ["properties", "content", "content"]))
                author = ValidString(ObjectUtils_Dig(comment, ["author", "displayName"]))
                if content <> "" then items.push({author: author, text: content})
            end if
        end for
    end if
    if items.count() = 0 then OverlayLegacyComments(data, items)
    if items.count() = 0 and input.firstPage and input.token <> ""
        input.token = ""
        return OverlayFetchComments(input, options)
    end if
    nextToken = ""
    actions = data.onResponseReceivedEndpoints
    if IsArray(actions)
        for each action in actions
            batch = ObjectUtils_Dig(action, ["appendContinuationItemsAction", "continuationItems"])
            if not IsArray(batch) then continue for
            for each entry in batch
                candidate = ValidString(ObjectUtils_Dig(entry, ["continuationItemRenderer", "continuationEndpoint", "continuationCommand", "token"]))
                if candidate <> "" then nextToken = candidate
            end for
        end for
    end if
    if nextToken = token then nextToken = ""
    return {items: items, continuation: nextToken}
end function

function OverlayInitialCommentsToken(videoId as string) as string
    contextBytes = CreateObject("roByteArray")
    writer = Protobuf_BinaryWriter()
    writer.SetBuffer(contextBytes)
    writer.WriteVarInt(18)
    writer.WriteString(videoId)

    sortBytes = CreateObject("roByteArray")
    writer.SetBuffer(sortBytes)
    writer.WriteVarInt(34)
    writer.WriteString(videoId)
    writer.WriteVarInt(120)
    writer.WriteVarInt(2)

    paramsBytes = CreateObject("roByteArray")
    writer.SetBuffer(paramsBytes)
    writer.WriteVarInt(34)
    writer.WriteProtoByteArray(sortBytes)
    writer.WriteVarInt(66)
    writer.WriteString("comments-section")

    tokenBytes = CreateObject("roByteArray")
    writer.SetBuffer(tokenBytes)
    writer.WriteVarInt(18)
    writer.WriteProtoByteArray(contextBytes)
    writer.WriteVarInt(24)
    writer.WriteVarInt(6)
    writer.WriteVarInt(50)
    writer.WriteProtoByteArray(paramsBytes)
    return tokenBytes.ToBase64String().EncodeUriComponent()
end function

function OverlayPublicDescription(videoId as string, cancellation as object) as string
    if not CreateObject("roRegex", "^[a-zA-Z0-9_-]{11}$", "").IsMatch(videoId) then return ""
    request = HttpClient_Get("https://www.youtube.com/watch?v=" + videoId)
    request.Headers({"user-agent": "Mozilla/5.0", "accept": "text/html"})
    request.Cancellation(cancellation)
    response = request.Await()
    if not response.IsSuccess() then return ""
    html = response.Text()
    quote = Chr(34)
    pattern = quote + "shortDescription" + quote + "\s*:\s*(" + quote + "(?:[^" + quote + "\\]|\\.)*" + quote + ")"
    match = CreateObject("roRegex", pattern, "").Match(html)
    if match.count() <> 2 then return ""
    decoded = ParseJson("[" + match[1] + "]")
    if not IsArray(decoded) or decoded.count() = 0 then return ""
    return ValidString(decoded[0])
end function

function OverlayCommentToken(node as dynamic) as string
    if IsAssociativeArray(node)
        section = node.itemSectionRenderer
        if section <> invalid
            target = ValidString(section.targetId)
            identifier = ValidString(section.sectionIdentifier)
            if target = "comments-section" or identifier = "comment-item-section"
                command = OverlayFindNode(section, "continuationCommand")
                if command <> invalid then return ValidString(command.token)
            end if
        end if
        panel = node.engagementPanelSectionListRenderer
        if panel <> invalid and ValidString(panel.targetId) = "engagement-panel-comments-section"
            command = OverlayFindNode(panel.content, "continuationCommand")
            if command <> invalid then return ValidString(command.token)
        end if
        for each key in node
            token = OverlayCommentToken(node[key])
            if token <> "" then return token
        end for
    else if IsArray(node)
        for each child in node
            token = OverlayCommentToken(child)
            if token <> "" then return token
        end for
    end if
    return ""
end function

function OverlayFindNode(node as dynamic, name as string) as dynamic
    if IsAssociativeArray(node)
        if node.DoesExist(name) then return node[name]
        for each key in node
            found = OverlayFindNode(node[key], name)
            if found <> invalid then return found
        end for
    else if IsArray(node)
        for each child in node
            found = OverlayFindNode(child, name)
            if found <> invalid then return found
        end for
    end if
    return invalid
end function

sub OverlayLegacyComments(node as dynamic, items as object)
    if IsAssociativeArray(node)
        comment = node.commentRenderer
        if comment <> invalid
            content = Innertube_ParseText(comment.contentText)
            if content <> ""
                items.push({author: Innertube_ParseText(comment.authorText), text: content})
            end if
            return
        end if
        for each key in node
            OverlayLegacyComments(node[key], items)
        end for
    else if IsArray(node)
        for each child in node
            OverlayLegacyComments(child, items)
        end for
    end if
end sub
