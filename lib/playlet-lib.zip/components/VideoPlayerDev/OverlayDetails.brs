sub ResetOverlayDetails()
    if m.overlayDetailsJob <> invalid then m.overlayDetailsJob.cancel = true
    if m.overlayActionJob <> invalid then m.overlayActionJob.cancel = true
    m.overlayDetailsJob = invalid
    m.overlayActionJob = invalid
    m.overlayPanelView.visible = false
    m.overlayResumeAfterPanel = false
    m.overlayChannelId = ""
    m.overlayRating = ""
    m.overlaySubscribed = invalid
    m.overlayDescription = ""
    m.overlayCommentsToken = ""
    m.overlayCommentsNext = ""
    m.overlayComments = []
    m.overlayAvatar.visible = false
    m.overlayTitleLayout.translation = [68, 40]
    UpdateOverlayButtons()
end sub

sub StartOverlayDetails(metadata as object)
    m.overlayChannelId = ValidString(metadata.authorId)
    m.overlayDescription = ValidString(metadata.description)
    if IsArray(metadata.authorThumbnails) and metadata.authorThumbnails.count() > 0
        SetOverlayAvatar(ValidString(metadata.authorThumbnails[0].url))
    end if
    m.overlayDetailsJob = JobSystem_CreateCallback(OverlayDetailsDone)
    JobSystem_QueueJob(m.jobQueue, "OverlayDetailsJob", OverlayJobInput("details"), m.overlayDetailsJob)
end sub

function OverlayJobInput(action as string) as object
    return {
        videoId: m.top.content.videoId
        channelId: m.overlayChannelId
        profile: m.top.profilesService.currentProfile
        hasDescription: m.overlayDescription <> ""
        action: action
    }
end function

sub OverlayDetailsDone(event as object)
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    if m.overlayDetailsJob = invalid or not m.overlayDetailsJob.isSameNode(callback) then return
    m.overlayDetailsJob = invalid
    info = event.getInfo()
    if m.onCloseCalled or not info.success then return
    details = info.data
    SetOverlayAvatar(ValidString(details.avatar))
    if m.overlayDescription = "" then m.overlayDescription = ValidString(details.description)
    if m.overlayPanelView.visible and m.overlayPanelTitle = "Description" and m.overlayPanelPages.count() = 0
        m.overlayPanelPages = OverlayDescriptionPages()
        PaintOverlayPanel()
    end if
    if m.overlayRating = "" then m.overlayRating = ValidString(details.rating)
    if m.overlaySubscribed = invalid then m.overlaySubscribed = details.subscribed
    m.overlayCommentsToken = ValidString(details.commentToken)
    UpdateOverlayButtons()
end sub

sub SetOverlayAvatar(uri as string)
    if uri = "" then return
    if Left(uri, 2) = "//" then uri = "https:" + uri
    m.overlayAvatar.uri = uri
    m.overlayAvatar.visible = true
    m.overlayTitleLayout.translation = [138, 40]
end sub

sub UpdateOverlayButtons()
    m.buttonRow.rating = m.overlayRating
    m.buttonRow.subscribed = m.overlaySubscribed = true
    m.buttonRow.captionsOn = LCase(ValidString(m.top.globalCaptionMode)) = "on"
end sub

sub ToggleOverlayCaptions()
    if LCase(ValidString(m.top.globalCaptionMode)) = "on"
        m.top.globalCaptionMode = "Off"
    else
        tracks = m.top.availableSubtitleTracks
        if not IsArray(tracks) or tracks.count() = 0
            metadata = m.top.content.metadata
            if IsAssociativeArray(metadata) and (not IsArray(metadata.captions) or metadata.captions.count() = 0)
                DialogUtils_ShowDialogEx({title: "Closed captions", message: "This video has no captions."})
                return
            end if
        else if m.top.currentSubtitleTrack = "" and m.top.subtitleTrack = ""
            m.top.subtitleTrack = tracks[0].TrackName
        end if
        m.top.globalCaptionMode = "On"
    end if
    UpdateOverlayButtons()
end sub

sub ShowOverlayDescription()
    if m.overlayDescription = "" and m.overlayDetailsJob <> invalid
        OpenOverlayPanel("Description", [])
    else
        OpenOverlayPanel("Description", OverlayDescriptionPages())
    end if
end sub

function OverlayDescriptionPages() as object
    if m.overlayDescription = "" then return ["No description is available."]
    pages = []
    lines = []
    for each paragraph in m.overlayDescription.Replace(Chr(13), "").Split(Chr(10))
        remaining = paragraph
        while remaining.Len() > 68
            splitAt = 68
            while splitAt > 45 and Mid(remaining, splitAt, 1) <> " "
                splitAt -= 1
            end while
            if splitAt = 45 then splitAt = 68
            lines.push(Left(remaining, splitAt).Trim())
            if lines.count() = 9
                pages.push(lines.Join(Chr(10)))
                lines = []
            end if
            remaining = Mid(remaining, splitAt + 1).Trim()
        end while
        lines.push(remaining)
        if lines.count() = 9
            pages.push(lines.Join(Chr(10)))
            lines = []
        end if
    end for
    if lines.count() > 0 then pages.push(lines.Join(Chr(10)))
    return pages
end function

sub ShowOverlayComments()
    OpenOverlayPanel("Comments", [])
    if m.overlayComments.count() > 0
        m.overlayPanelPages = m.overlayComments
        PaintOverlayPanel()
    else
        RequestOverlayComments(m.overlayCommentsToken)
    end if
end sub

sub OpenOverlayPanel(title as string, pages as object)
    m.overlayResumeAfterPanel = not m.transport.isLive and m.top.state = "playing"
    if m.overlayResumeAfterPanel then m.top.control = "pause"
    m.overlayPanelTitle = title
    m.overlayPanelPages = pages
    m.overlayPanelIndex = 0
    m.overlayPanelFocus = 0
    m.overlayPanelView.visible = true
    PaintOverlayPanel()
end sub

sub PaintOverlayPanel()
    if not m.overlayPanelView.visible then return
    count = m.overlayPanelPages.count()
    title = m.overlayPanelTitle
    body = "Loading…"
    if count > 0
        if count > 1 then title += " " + StrI(m.overlayPanelIndex + 1).Trim()
        body = m.overlayPanelPages[m.overlayPanelIndex]
    end if
    m.overlayPanelHeading.text = title
    m.overlayPanelBody.text = Left(body, 950)
    hasMore = m.overlayPanelTitle = "Comments" and m.overlayCommentsNext <> ""
    available = [true, m.overlayPanelIndex > 0, m.overlayPanelIndex < count - 1 or hasMore]
    if not available[m.overlayPanelFocus] then m.overlayPanelFocus = 0
    x = 40
    for i = 0 to m.overlayPanelButtons.count() - 1
        button = m.overlayPanelButtons[i]
        button.visible = available[i]
        button.focused = i = m.overlayPanelFocus
        if available[i]
            button.translation = [x, 460]
            x += 140
        end if
    end for
end sub

sub HandleOverlayPanelKey(key as string)
    if key = "back" or (key = "OK" and m.overlayPanelFocus = 0)
        m.overlayPanelView.visible = false
        if m.overlayResumeAfterPanel and m.top.state = "paused" then m.top.control = "resume"
        m.overlayResumeAfterPanel = false
        return
    end if
    if key = "left" or key = "right"
        stepSize = 1
        if key = "left" then stepSize = -1
        index = m.overlayPanelFocus + stepSize
        while index >= 0 and index < m.overlayPanelButtons.count()
            if m.overlayPanelButtons[index].visible
                m.overlayPanelFocus = index
                PaintOverlayPanel()
                return
            end if
            index += stepSize
        end while
    else if key = "OK"
        if m.overlayPanelFocus = 1
            m.overlayPanelIndex -= 1
            PaintOverlayPanel()
        else if m.overlayPanelIndex + 1 < m.overlayPanelPages.count()
            m.overlayPanelIndex += 1
            PaintOverlayPanel()
        else if m.overlayPanelTitle = "Comments" and m.overlayCommentsNext <> ""
            RequestOverlayComments(m.overlayCommentsNext)
        end if
    end if
end sub

sub RequestOverlayComments(token as string)
    if m.overlayActionJob <> invalid
        if m.overlayComments.count() = 0 and m.overlayPanelView.visible
            m.overlayPanelPages = ["Another action is in progress. Close this window and try again."]
            PaintOverlayPanel()
        end if
        return
    end if
    input = OverlayJobInput("comments")
    input.token = token
    input.firstPage = m.overlayComments.count() = 0
    m.overlayActionJob = JobSystem_CreateCallback(OverlayCommentsDone)
    JobSystem_QueueJob(m.jobQueue, "OverlayDetailsJob", input, m.overlayActionJob)
end sub

sub OverlayCommentsDone(event as object)
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    if m.overlayActionJob = invalid or not m.overlayActionJob.isSameNode(callback) then return
    m.overlayActionJob = invalid
    info = event.getInfo()
    if m.onCloseCalled or info.cancel then return
    startIndex = m.overlayComments.count()
    if info.success
        m.overlayCommentsNext = ValidString(info.data.continuation)
        for each item in info.data.items
            prefix = ""
            if item.author <> "" then prefix = item.author + Chr(10) + Chr(10)
            m.overlayComments.push(prefix + item.text)
        end for
    end if
    if not m.overlayPanelView.visible or m.overlayPanelTitle <> "Comments" then return
    if m.overlayComments.count() > 0
        m.overlayPanelPages = m.overlayComments
        if m.overlayComments.count() > startIndex then m.overlayPanelIndex = startIndex
    else if info.success
        m.overlayPanelPages = ["YouTube did not return any comments for this video."]
    else
        m.overlayPanelPages = [ValidString(info.error)]
    end if
    PaintOverlayPanel()
end sub

sub RunOverlayAccountAction(action as string)
    if m.overlayActionJob <> invalid then return
    profile = m.top.profilesService.currentProfile
    if profile = invalid or profile.type <> "youtube"
        DialogUtils_ShowDialogEx({title: "YouTube account", message: "Sign in to YouTube from Profile to use this control."})
        return
    end if
    if action = "subscribe"
        if m.overlayChannelId = "" then return
        if m.overlaySubscribed = true then action = "unsubscribe"
    else if action = m.overlayRating
        action = "removelike"
    end if
    m.overlayActionJob = JobSystem_CreateCallback(OverlayAccountActionDone)
    JobSystem_QueueJob(m.jobQueue, "OverlayDetailsJob", OverlayJobInput(action), m.overlayActionJob)
end sub

sub OverlayAccountActionDone(event as object)
    callback = event.getRoSGNode()
    JobSystem_UnobserveCallback(callback)
    if m.overlayActionJob = invalid or not m.overlayActionJob.isSameNode(callback) then return
    m.overlayActionJob = invalid
    info = event.getInfo()
    if m.onCloseCalled or info.cancel then return
    if not info.success
        DialogUtils_ShowDialogEx({title: "YouTube", message: ValidString(info.error)})
        return
    end if
    action = info.data.action
    if action = "subscribe" or action = "unsubscribe"
        m.overlaySubscribed = action = "subscribe"
    else if action = "removelike"
        m.overlayRating = "indifferent"
    else
        m.overlayRating = action
    end if
    UpdateOverlayButtons()
end sub
