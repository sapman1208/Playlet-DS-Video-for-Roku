sub Init()
    leftCluster = m.top.findNode("LeftCluster")
    centerCluster = m.top.findNode("CenterCluster")
    rightCluster = m.top.findNode("RightCluster")
    m.focusLabel = m.top.findNode("focusLabel")

    m.buttons = []
    for each cluster in [leftCluster, centerCluster, rightCluster]
        for each button in cluster.getChildren(-1, 0)
            if button.action = "togglePlayback" then m.playPauseIndex = m.buttons.count()
            m.buttons.push(button)
        end for
    end for
    m.top.buttonCount = m.buttons.count()

    LayoutCluster(leftCluster, 68)
    LayoutCluster(centerCluster, 640 - 21 - 58)
    LayoutCluster(rightCluster, 1212 - rightCluster.getChildCount() * 58 + 16)

    m.playPause = m.top.findNode("PlayPauseButton")
    m.like = m.top.findNode("LikeButton")
    m.dislike = m.top.findNode("DislikeButton")
    m.subscribe = m.top.findNode("SubscribeButton")
    m.captions = m.top.findNode("CaptionsButton")

    for each field in ["transportMode", "rowFocused", "focusedIndex", "playing", "rating", "subscribed", "captionsOn"]
        m.top.observeField(field, "Repaint")
    end for
    m.top.observeField("nudge", "OnNudge")
    Repaint()
end sub

sub LayoutCluster(cluster as object, x as integer)
    cluster.translation = [x, 560]
    for i = 0 to cluster.getChildCount() - 1
        cluster.getChild(i).translation = [i * 58, 0]
    end for
end sub

function GetPlayPauseIndex(_unused as dynamic) as integer
    return m.playPauseIndex
end function

function GetButtonAction(index as integer) as string
    if index < 0 or index >= m.buttons.count() then return ""
    return m.buttons[index].action
end function

sub OnNudge()
    index = m.top.focusedIndex
    if index >= 0 and index < m.buttons.count() then m.buttons[index].nudge = true
end sub

sub Repaint()
    m.top.visible = m.top.transportMode = 0
    m.playPause.toggleState = not m.top.playing
    m.playPause.focusLabel = "Play"
    if m.top.playing then m.playPause.focusLabel = "Pause"

    m.like.selected = m.top.rating = "like"
    m.dislike.selected = m.top.rating = "dislike"
    m.subscribe.selected = m.top.subscribed
    m.subscribe.focusLabel = "Subscribe"
    if m.top.subscribed then m.subscribe.focusLabel = "Subscribed"
    m.captions.selected = m.top.captionsOn
    m.captions.focusLabel = "CC off"
    if m.top.captionsOn then m.captions.focusLabel = "CC on"

    m.focusLabel.visible = false
    for i = 0 to m.buttons.count() - 1
        button = m.buttons[i]
        button.focused = m.top.rowFocused and i = m.top.focusedIndex
        if button.focused
            x = button.getParent().translation[0] + button.translation[0] + 21
            m.focusLabel.translation = [x - 112, 526]
            m.focusLabel.text = button.focusLabel
            m.focusLabel.visible = true
        end if
    end for
end sub
