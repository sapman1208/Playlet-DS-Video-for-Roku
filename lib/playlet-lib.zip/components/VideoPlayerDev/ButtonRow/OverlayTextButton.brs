sub onStyleChanged()
    plate = m.top.findNode("plate")
    label = m.top.findNode("label")
    if m.top.focused
        plate.color = "#F5F5F5"
        label.color = "#202020"
    else if m.top.selected
        plate.color = "#A3283C"
        label.color = "#FFFFFF"
    else
        plate.color = "#343434"
        label.color = "#FFFFFF"
    end if
end sub
