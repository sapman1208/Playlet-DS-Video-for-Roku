'import "pkg:/components/Services/Innertube/InnertubeService.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
function __Http_PlayletInvidiousBackendRouter_method_new(server as object)
    m.super0_new()
    m.innertube = server.sceneNodes.innertube
    m.loungeService = server.sceneNodes.loungeService
    m.preferences = server.sceneNodes.preferences
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/authorize_token", router: m, func: "AuthorizeToken" })
    m.routes.push({ method: "POST", path: "/playlet-invidious-backend/api/v1/auth/tokens/unregister", router: m, func: "UnregisterToken" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/feed", router: m, func: "GetAuthFeed" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/subscriptions", router: m, func: "GetAuthSubscriptions" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/playlists", router: m, func: "GetAuthPlaylists" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/auth/history", router: m, func: "GetAuthHistory" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/stats", router: m, func: "GetStats" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/trending", router: m, func: "GetTrending" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/popular", router: m, func: "GetPopular" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/search/suggestions", router: m, func: "GetSearchSuggestions" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/search", router: m, func: "GetSearch" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/api/v1/resolveurl", router: m, func: "ResolveUrl" })
    m.routes.push({ method: "GET", path: "*", router: m, func: "GetAll" })
    m.routes.push({ method: "POST", path: "*", router: m, func: "PostAll" })
    m.routes.push({ method: "DELETE", path: "*", router: m, func: "DeleteAll" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/watch", router: m, func: "RedirectWatch" })
    m.routes.push({ method: "GET", path: "/playlet-invidious-backend/playlist", router: m, func: "RedirectPlaylist" })
end function
function __Http_PlayletInvidiousBackendRouter_method_AuthorizeToken(context as object) as boolean
    response = context.response
    response.Json({
        "error": "Playlet built-in Invidious backend is not a real Invidious instance, and does not support accounts. Please use the login with YouTube option instead."
    })
    response.http_code = 400
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_UnregisterToken(context as object) as boolean
    request = context.request
    response = context.response
    token = request.BodyText()
    if StringUtils_IsNullOrEmpty(token)
        response.Json({
            "error": "Missing 'token' body parameter"
        })
        response.http_code = 400
        return true
    end if
    if not InnertubeService_AuthRevokeToken(token)
        response.Json({
            "error": "Failed to revoke token"
        })
        response.http_code = 500
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthFeed(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
        "disableShorts": m.preferences["content_feed.disable_shorts"]
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    result = InnertubeService_GetSubscriptions(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        
        response.Json({
            "videos": []
        })
        return true
    end if
    responseBody = {
        "videos": ValidArray(result.feeds[0].items)
    }
    if result.feeds[0].DoesExist("continuation")
        responseBody.continuation = result.feeds[0].continuation
    end if
    response.Json(responseBody)
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthSubscriptions(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = { accessToken: accessToken }
    if not StringUtils_IsNullOrEmpty(request.query.activeIdentifyToken)
        options.onBehalfOfUser = request.query.activeIdentifyToken
    end if
    if not StringUtils_IsNullOrEmpty(request.query.continuation)
        options.continuation = request.query.continuation
    end if
    result = InnertubeService_GetBrowseAuthenticatedPage("FEchannels", options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    channels = []
    seen = {}
    continuation = ""
    for each feed in result.feeds
        if not StringUtils_IsNullOrEmpty(feed.continuation) then continuation = feed.continuation
        for each item in feed.items
            if item.type = "channel" and not StringUtils_IsNullOrEmpty(item.authorId) and not seen.DoesExist(item.authorId)
                seen[item.authorId] = true
                channels.push(item)
            end if
        end for
    end for
    if request.query.asFeed = "true"
        page = {items: channels}
        if continuation <> "" and continuation <> options.continuation then page.continuation = continuation
        response.Json(page)
    else
        response.Json(channels)
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylists(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    result = InnertubeService_GetPlaylists(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        response.Json({
            "error": "Failed to get auth playlists"
        })
        response.http_code = 500
        return true
    end if
    response.Json(result.feeds[0])
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthHistory(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    hasContinuation = not StringUtils_IsNullOrEmpty(continuation)
    if hasContinuation
        options.continuation = continuation
    end if
    if not hasContinuation
        page = ValidString(request.query.page).ToInt()
        if page > 1
            LogErrorNoTelemetry2("[PlayletInvidiousBackendRouter.bs:200]", "Playlet backend does not use history pagination (use continuation instead)")
            response.Json({
                "items": []
            })
            return true
        end if
    end if
    result = InnertubeService_GetWatchHistory(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        
        response.Json({
            "items": []
        })
        return true
    end if
    response.Json(result.feeds[0])
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetStats(context as object) as boolean
    response = context.response
    response.Json({
        "error": "Playlet built-in Invidious backend is not a real Invidious instance, and does not support stats."
    })
    response.http_code = 400
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetTrending(context as object) as boolean
    request = context.request
    response = context.response
    raw = request.query.raw <> invalid
    options = {
        "disableShorts": m.preferences["content_feed.disable_shorts"]
        raw: raw
        type: request.query.type
    }
    result = InnertubeService_GetTrending(options)
    if raw
        response.Json(result)
        return true
    end if
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        response.Json({
            "error": "Failed to get trending feed"
        })
        response.http_code = 500
        return true
    end if
    response.Json(ValidArray(result.feeds[0].items))
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetPopular(context as object) as boolean
    request = context.request
    response = context.response
    isRecommended = request.query.recommended = "true"
    if isRecommended
        return m.GetAuthRecommended(context)
    end if
    response.Json({
        "error": "Playlet built-in Invidious backend does not support popular videos."
    })
    response.http_code = 400
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthRecommended(context as object) as boolean
    request = context.request
    response = context.response
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    options = {
        "accessToken": accessToken
        "disableShorts": m.preferences["content_feed.disable_shorts"]
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    continuation = request.query.continuation
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    category = request.query.recommendationCategory
    if category = "shorts" or category = "music"
        row = 0
        if request.query.recommendationRow = "1" then row = 1
        result = InnertubeService_GetPersonalRecommendations(category, row, options)
        if result.error <> invalid then response.http_code = 500
        response.Json(result)
        return true
    end if
    result = InnertubeService_GetHome(options)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    if not IsArray(result.feeds) or result.feeds.Count() = 0
        
        response.Json({
            "items": []
        })
        return true
    end if
    response.Json(result.feeds[0])
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetSearchSuggestions(context as object) as boolean
    request = context.request
    response = context.response
    query = request.query.q
    result = InnertubeService_SearchSuggestions(query)
    if result.error <> invalid
        response.Json(result)
        response.http_code = 500
        return true
    end if
    result.query = query
    if result.DoesExist("cache-control")
        response.headers["cache-control"] = result["cache-control"]
    end if
    response.Json(result)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetSearch(context as object) as boolean
    request = context.request
    response = context.response
    query = request.query.q
    continuation = request.query.continuation
    raw = request.query.raw <> invalid
    options = {
        "disableShorts": m.preferences["content_feed.disable_shorts"]
        raw: raw
    }
    searchFilters = {}
    sort = request.query.sort
    if not StringUtils_IsNullOrEmpty(sort)
        searchFilters.sort = sort
    end if
    date = request.query.date
    if not StringUtils_IsNullOrEmpty(date)
        searchFilters.date = date
    end if
    _type = request.query.type
    if not StringUtils_IsNullOrEmpty(_type)
        searchFilters.type = _type
    end if
    duration = request.query.duration
    if not StringUtils_IsNullOrEmpty(duration)
        searchFilters.duration = duration
    end if
    features = request.query.features
    if not StringUtils_IsNullOrEmpty(features)
        searchFilters.features = features.Split(",")
    end if
    if searchFilters.Count() > 0
        options.searchFilters = searchFilters
    end if
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    fetchedPages = 0
    while true
        
        if fetchedPages > 3
            response.Json({
                "error": "Failed to search: no results found"
            })
            response.http_code = 500
            return true
        end if
        result = InnertubeService_Search(query, options)
        fetchedPages += 1
        if raw
            response.Json(result)
            return true
        end if
        if result.error <> invalid
            response.Json(result)
            response.http_code = 500
            return true
        end if
        if not IsArray(result.feeds) or result.feeds.Count() = 0
            response.Json({
                "error": "Failed to search: no results found"
            })
            response.http_code = 500
            return true
        end if
        feed = result.feeds[0]
        if feed.items.Count() > 0
            response.Json(feed)
            if fetchedPages = 1 and result.DoesExist("cache-control")
                response.headers["cache-control"] = result["cache-control"]
            end if
            return true
        end if
        if StringUtils_IsNullOrEmpty(feed.continuation)
            response.Json({
                "error": "Failed to search: no results found"
            })
            response.http_code = 500
            return true
        end if
        
        options.continuation = feed.continuation
    end while
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_ResolveUrl(context as object) as boolean
    request = context.request
    response = context.response
    url = request.query.url
    raw = request.query.raw <> invalid
    if StringUtils_IsNullOrEmpty(url)
        response.Json({
            "error": "Missing 'url' query parameter"
        })
        response.http_code = 400
        return true
    end if
    json = InnertubeService_ResolveUrl(url)
    if json = invalid
        response.Json({
            "error": "Failed to resolve URL"
        })
        response.http_code = 500
        return true
    end if
    if raw
        response.Json(json)
        return true
    end if
    endpoint = json["endpoint"]
    pageType = ValidString(ObjectUtils_Dig(endpoint, [
        "commandMetadata"
        "webCommandMetadata"
        "webPageType"
    ]))
    if pageType = "WEB_PAGE_TYPE_UNKNOWN" or pageType = ""
        response.Json({
            "error": "Unknown page type"
        })
        response.http_code = 400
        return true
    end if
    subEndpoint = endpoint["watchEndpoint"]
    if subEndpoint = invalid
        subEndpoint = endpoint["browseEndpoint"]
        if subEndpoint = invalid
            subEndpoint = endpoint
        end if
    end if
    params = ObjectUtils_Dig(subEndpoint, [
        "params"
    ])
    result = {
        "pageType": pageType
    }
    browseId = ObjectUtils_Dig(subEndpoint, [
        "browseId"
    ])
    if not StringUtils_IsNullOrEmpty(browseId)
        result["ucid"] = browseId
    end if
    videoId = ObjectUtils_Dig(subEndpoint, [
        "videoId"
    ])
    if not StringUtils_IsNullOrEmpty(videoId)
        result["videoId"] = videoId
    end if
    playlistId = ObjectUtils_Dig(subEndpoint, [
        "playlistId"
    ])
    if not StringUtils_IsNullOrEmpty(playlistId)
        result["playlistId"] = playlistId
    end if
    startTimeSeconds = ObjectUtils_Dig(subEndpoint, [
        "startTimeSeconds"
    ])
    if ValidInt(startTimeSeconds) > 0
        result["startTimeSeconds"] = startTimeSeconds
    end if
    if IsString(params)
        result["params"] = params
    end if
    response.Json(result)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAll(context as object) as boolean
    request = context.request
    route = request.route
    if route.StartsWith("/playlet-invidious-backend/api/v1/videos/")
        return m.GetVideo(context)
    else if route.StartsWith("/playlet-invidious-backend/api/v1/playlists/")
        return m.GetPlaylist(context)
    else if route.StartsWith("/playlet-invidious-backend/api/v1/auth/playlists/")
        return m.GetAuthPlaylist(context)
    else if route.StartsWith("/playlet-invidious-backend/api/v1/channels/")
        return m.GetChannel(context)
    else if route.StartsWith("/playlet-invidious-backend/channel")
        return m.RedirectChannel(context)
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_PostAll(context as object) as boolean
    request = context.request
    route = request.route
    if route.StartsWith("/playlet-invidious-backend/api/v1/auth/subscriptions/")
        return m.SubscribeToChannel(context)
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_GetVideo(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    videoId = route.Mid("/playlet-invidious-backend/api/v1/videos/".Len())
    if videoId.InStr("?") > 0
        videoId = videoId.Left(videoId.InStr("?"))
    end if
    raw = request.query.raw <> invalid
    videoInfoBatched = request.query.video_info_batched <> invalid
    visitorData = ""
    sessionData = m.innertube.sessionData
    if IsAssociativeArray(sessionData)
        visitorData = ValidString(sessionData.visitorData)
    end if
    options = {
        "raw": raw
        "visitorData": visitorData
    }
    if videoInfoBatched
        options["retry"] = false
        metadata = InnertubeService_GetVideoInfoBatched([
            videoId
        ], options)
        if IsArray(metadata.videos) and metadata.videos.Count() > 0
            metadata = metadata.videos[0]
        else
            metadata = {
                "error": "Failed to get video info with video_info_batched=true"
            }
        end if
    else
        options["credentialTransferToken"] = m.loungeService.credentialTransferToken
        metadata = InnertubeService_GetVideoMetadata(videoId, options)
    end if
    response.Json(metadata)
    if metadata.error <> invalid
        response.http_code = 500
        return true
    end if
    
    if videoInfoBatched
        response.headers["cache-control"] = "public, max-age=259200" 
    end if
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetPlaylist(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    playlistId = context.playlistId
    if StringUtils_IsNullOrEmpty(playlistId)
        playlistId = route.Mid("/playlet-invidious-backend/api/v1/playlists/".Len())
        if playlistId.InStr("?") > 0
            playlistId = playlistId.Left(playlistId.InStr("?"))
        end if
    end if
    continuation = request.query.continuation
    raw = request.query.raw <> invalid
    infoOnly = request.query.info_only <> invalid
    options = {
        raw: raw
    }
    accessToken = m.GetAccessToken(request)
    if accessToken <> invalid
        options["accessToken"] = accessToken
        activeIdentifyToken = request.query.activeIdentifyToken
        if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
            options.onBehalfOfUser = activeIdentifyToken
        end if
    end if
    if playlistId.StartsWith("RD")
        if not StringUtils_IsNullOrEmpty(continuation)
            options.videoId = continuation
        else
            videoId = request.query.videoId
            if not StringUtils_IsNullOrEmpty(videoId)
                options.videoId = videoId
            end if
        end if
        playlist = InnertubeService_GetMix(playlistId, options)
    else
        if not StringUtils_IsNullOrEmpty(continuation)
            options.continuation = continuation
        end if
        playlist = InnertubeService_GetPlaylist(playlistId, options)
    end if
    if raw
        response.Json(playlist)
        return true
    end if
    if playlist.error <> invalid
        response.Json(playlist)
        response.http_code = 500
        return true
    end if
    index = request.query.index
    if not StringUtils_IsNullOrEmpty(index)
        index = index.ToInt()
        if index > 1
            LogErrorNoTelemetry2("[PlayletInvidiousBackendRouter.bs:698]", "Playlet backend does not use playlist pagination (use continuation instead)")
            playlist.videos = []
        end if
    end if
    
    if infoOnly
        playlist.videos = []
        playlist.Delete("continuation")
    end if
    response.Json(playlist)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylist(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    playlistId = route.Mid("/playlet-invidious-backend/api/v1/auth/playlists/".Len())
    if playlistId.InStr("?") > 0
        playlistId = playlistId.Left(playlistId.InStr("?"))
    end if
    context.playlistId = playlistId
    return m.GetPlaylist(context)
end function
function __Http_PlayletInvidiousBackendRouter_method_GetChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    channelAndTab = route.Mid("/playlet-invidious-backend/api/v1/channels/".Len())
    if channelAndTab.InStr("?") > 0
        channelAndTab = channelAndTab.Left(channelAndTab.InStr("?"))
    end if
    channelAndTab = channelAndTab.Split("/")
    continuation = request.query.continuation
    raw = request.query.raw <> invalid
    options = {
        raw: raw
    }
    if not StringUtils_IsNullOrEmpty(continuation)
        options.continuation = continuation
    end if
    if channelAndTab.Count() = 1
        channelId = channelAndTab[0]
        channel = InnertubeService_GetChannel(channelId, options)
        if raw
            response.Json(channel)
            return true
        end if
        if channel.error <> invalid
            response.Json(channel)
            response.http_code = 500
            return true
        end if
        response.Json(channel)
        if channel.DoesExist("cache-control")
            response.headers["cache-control"] = channel["cache-control"]
        end if
        return true
    else if channelAndTab.Count() = 2
        channelId = channelAndTab[0]
        _tab = channelAndTab[1]
        params = request.query.params
        if not StringUtils_IsNullOrEmpty(params)
            options.params = params
        end if
        
        sortBy = request.query.sort_by
        if not StringUtils_IsNullOrEmpty(sortBy) and sortBy.StartsWith("{")
            sortBy = StringUtils_ParseJsonSafe(sortBy)
            if IsAssociativeArray(sortBy)
                if sortBy.DoesExist("params")
                    options.params = sortBy.params
                end if
                if sortBy.DoesExist("continuation")
                    options.continuation = sortBy.continuation
                end if
            end if
        end if
        channel = InnertubeService_GetChannel(channelId, options)
        if raw
            response.Json(channel)
            return true
        end if
        if channel.error <> invalid
            response.Json(channel)
            response.http_code = 500
            return true
        end if
        result = {}
        if _tab = "playlists" or _tab = "podcasts" or _tab = "releases" or _tab = "courses"
            result["playlists"] = channel.items
        else
            result["videos"] = channel.items
        end if
        if channel.DoesExist("continuation")
            result.continuation = channel.continuation
        end if
        if channel.DoesExist("sortOptions")
            
            sortOptions = channel.sortOptions
            if IsArray(sortOptions) and sortOptions.Count() > 0
                for i = 0 to sortOptions.Count() - 1
                    sortOption = sortOptions[i]
                    sortOptionId = {}
                    if sortOption.DoesExist("params")
                        sortOptionId["params"] = sortOption.params
                    end if
                    if sortOption.DoesExist("continuation")
                        sortOptionId["continuation"] = sortOption.continuation
                    end if
                    sortOption.id = FormatJson(sortOptionId)
                end for
            end if
            result["sortOptions"] = sortOptions
        end if
        response.Json(result)
        if channel.DoesExist("cache-control")
            response.headers["cache-control"] = channel["cache-control"]
        end if
        return true
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_SubscribeToChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    channelId = route.Mid("/playlet-invidious-backend/api/v1/auth/subscriptions/".Len())
    if channelId.InStr("?") > 0
        channelId = channelId.Left(channelId.InStr("?"))
    end if
    if StringUtils_IsNullOrEmpty(channelId)
        response.Json({
            "error": "Missing 'channelId' path parameter"
        })
        response.http_code = 400
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    result = InnertubeService_SubscribeToChannel(channelId, options)
    if result.success <> true
        response.Json(result)
        response.http_code = 500
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_DeleteAll(context as object) as boolean
    request = context.request
    route = request.route
    if route.StartsWith("/playlet-invidious-backend/api/v1/auth/subscriptions/")
        return m.UnsubscribeFromChannel(context)
    end if
    return false
end function
function __Http_PlayletInvidiousBackendRouter_method_UnsubscribeFromChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    accessToken = m.RequireAccessToken(request, response)
    if accessToken = invalid
        return true
    end if
    channelId = route.Mid("/playlet-invidious-backend/api/v1/auth/subscriptions/".Len())
    if channelId.InStr("?") > 0
        channelId = channelId.Left(channelId.InStr("?"))
    end if
    if StringUtils_IsNullOrEmpty(channelId)
        response.Json({
            "error": "Missing 'channelId' path parameter"
        })
        response.http_code = 400
        return true
    end if
    options = {
        "accessToken": accessToken
    }
    activeIdentifyToken = request.query.activeIdentifyToken
    if not StringUtils_IsNullOrEmpty(activeIdentifyToken)
        options.onBehalfOfUser = activeIdentifyToken
    end if
    result = InnertubeService_UnsubscribeFromChannel(channelId, options)
    if result.success <> true
        response.Json(result)
        response.http_code = 500
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RedirectWatch(context as object) as boolean
    request = context.request
    response = context.response
    videoId = request.query.v
    t = request.query.t
    if StringUtils_IsNullOrEmpty(videoId)
        response.Json({
            "error": "Missing 'v' query parameter"
        })
        response.http_code = 400
        return true
    end if
    url = ("https://redirect.invidious.io/watch?v=" + bslib_toString(videoId))
    if not StringUtils_IsNullOrEmpty(t)
        url = (bslib_toString(url) + "&t=" + bslib_toString(t))
    end if
    response.Redirect(url)
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RedirectPlaylist(context as object) as boolean
    request = context.request
    response = context.response
    playlistId = request.query.list
    if StringUtils_IsNullOrEmpty(playlistId)
        response.Json({
            "error": "Missing 'list' query parameter"
        })
        response.http_code = 400
        return true
    end if
    response.Redirect(("https://redirect.invidious.io/playlist?list=" + bslib_toString(playlistId)))
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_RedirectChannel(context as object) as boolean
    request = context.request
    response = context.response
    route = request.route
    channelId = route.Mid("/playlet-invidious-backend/channel/".Len())
    if StringUtils_IsNullOrEmpty(channelId)
        response.Json({
            "error": "Missing 'channelId' path parameter"
        })
        response.http_code = 400
        return true
    end if
    response.Redirect(("https://redirect.invidious.io/channel/" + bslib_toString(channelId)))
    return true
end function
function __Http_PlayletInvidiousBackendRouter_method_GetAccessToken(request as object) as dynamic
    accessToken = request.headers["authorization"]
    if StringUtils_IsNullOrEmpty(accessToken) or not accessToken.StartsWith("Bearer ")
        return invalid
    end if
    return accessToken.Mid("Bearer ".Len())
end function
function __Http_PlayletInvidiousBackendRouter_method_RequireAccessToken(request as object, response as object) as dynamic
    accessToken = m.GetAccessToken(request)
    if accessToken = invalid
        response.Json({
            "error": "Missing or invalid 'Authorization' header. Please login again."
        })
        response.http_code = 403
        return invalid
    end if
    return accessToken
end function
function __Http_PlayletInvidiousBackendRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_PlayletInvidiousBackendRouter_method_new
    instance.AuthorizeToken = __Http_PlayletInvidiousBackendRouter_method_AuthorizeToken
    instance.UnregisterToken = __Http_PlayletInvidiousBackendRouter_method_UnregisterToken
    instance.GetAuthFeed = __Http_PlayletInvidiousBackendRouter_method_GetAuthFeed
    instance.GetAuthSubscriptions = __Http_PlayletInvidiousBackendRouter_method_GetAuthSubscriptions
    instance.GetAuthPlaylists = __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylists
    instance.GetAuthHistory = __Http_PlayletInvidiousBackendRouter_method_GetAuthHistory
    instance.GetStats = __Http_PlayletInvidiousBackendRouter_method_GetStats
    instance.GetTrending = __Http_PlayletInvidiousBackendRouter_method_GetTrending
    instance.GetPopular = __Http_PlayletInvidiousBackendRouter_method_GetPopular
    instance.GetAuthRecommended = __Http_PlayletInvidiousBackendRouter_method_GetAuthRecommended
    instance.GetSearchSuggestions = __Http_PlayletInvidiousBackendRouter_method_GetSearchSuggestions
    instance.GetSearch = __Http_PlayletInvidiousBackendRouter_method_GetSearch
    instance.ResolveUrl = __Http_PlayletInvidiousBackendRouter_method_ResolveUrl
    instance.GetAll = __Http_PlayletInvidiousBackendRouter_method_GetAll
    instance.PostAll = __Http_PlayletInvidiousBackendRouter_method_PostAll
    instance.GetVideo = __Http_PlayletInvidiousBackendRouter_method_GetVideo
    instance.GetPlaylist = __Http_PlayletInvidiousBackendRouter_method_GetPlaylist
    instance.GetAuthPlaylist = __Http_PlayletInvidiousBackendRouter_method_GetAuthPlaylist
    instance.GetChannel = __Http_PlayletInvidiousBackendRouter_method_GetChannel
    instance.SubscribeToChannel = __Http_PlayletInvidiousBackendRouter_method_SubscribeToChannel
    instance.DeleteAll = __Http_PlayletInvidiousBackendRouter_method_DeleteAll
    instance.UnsubscribeFromChannel = __Http_PlayletInvidiousBackendRouter_method_UnsubscribeFromChannel
    instance.RedirectWatch = __Http_PlayletInvidiousBackendRouter_method_RedirectWatch
    instance.RedirectPlaylist = __Http_PlayletInvidiousBackendRouter_method_RedirectPlaylist
    instance.RedirectChannel = __Http_PlayletInvidiousBackendRouter_method_RedirectChannel
    instance.GetAccessToken = __Http_PlayletInvidiousBackendRouter_method_GetAccessToken
    instance.RequireAccessToken = __Http_PlayletInvidiousBackendRouter_method_RequireAccessToken
    return instance
end function
function Http_PlayletInvidiousBackendRouter(server as object)
    instance = __Http_PlayletInvidiousBackendRouter_builder()
    instance.new(server)
    return instance
end function