'import "pkg:/components/Dialog/DialogUtils.bs"
'import "pkg:/components/Web/WebServer/Http/HttpRouter.bs"
'import "pkg:/source/utils/RegistryUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/Types.bs"
function __Http_PlayletLibUrlsRouter_method_new(server as object)
    m.super0_new()
    m.scene = server.task.getScene()
    m.routes.push({ method: "GET", path: "/api/playlet-lib-urls", router: m, func: "GetPlayletLibUrls" })
    m.routes.push({ method: "POST", path: "/api/playlet-lib-urls/code", router: m, func: "ShowSetPlayletLibUrlsCode" })
    m.routes.push({ method: "POST", path: "/api/playlet-lib-urls", router: m, func: "SetPlayletLibUrls" })
    m.routes.push({ method: "DELETE", path: "/api/playlet-lib-urls", router: m, func: "DeletePlayletLibUrls" })
end function
function __Http_PlayletLibUrlsRouter_method_GetPlayletLibUrls(context as object) as boolean
    response = context.response
    saved = RegistryUtils_Read("playlet_lib_urls")
    if saved <> invalid
        saved = StringUtils_ParseJsonSafe(saved)
    end if
    response.Json({
        loaded: m.scene.playletLibLoadedUrl
        saved: saved
    })
    return true
end function
function __Http_PlayletLibUrlsRouter_method_ShowSetPlayletLibUrlsCode(context as object) as boolean
    response = context.response
    
    dialog = DialogUtils_ShowOnScreenCodeDialog("SetPlayletLibUrls", "Change Playlet library")
    if dialog = invalid
        response.Default(429, "Too Many Requests")
        return true
    end if
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletLibUrlsRouter_method_SetPlayletLibUrls(context as object) as boolean
    request = context.request
    response = context.response
    if not DialogUtils_ConsumeOnScreenCode("SetPlayletLibUrls", request.query.code)
        response.Default(400, "Invalid code")
        return true
    end if
    payload = request.BodyJson()
    if payload = invalid or not IsArray(payload)
        response.Default(400, "Invalid payload")
        return true
    end if
    if payload.Count() = 0
        response.Default(400, "Payload must contain at least one item")
        return true
    end if
    for each item in payload
        if StringUtils_IsNullOrEmpty(item.link) or StringUtils_IsNullOrEmpty(item.type)
            response.Default(400, ("Invalid item in array (must have " + chr(34) + "link" + chr(34) + " and " + chr(34) + "type" + chr(34) + " properties)"))
            return true
        end if
    end for
    RegistryUtils_Write("playlet_lib_urls", request.BodyText())
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletLibUrlsRouter_method_DeletePlayletLibUrls(context as object) as boolean
    response = context.response
    RegistryUtils_Delete("playlet_lib_urls")
    response.Default(204, "OK")
    return true
end function
function __Http_PlayletLibUrlsRouter_builder()
    instance = __Http_HttpRouter_builder()
    instance.super0_new = instance.new
    instance.new = __Http_PlayletLibUrlsRouter_method_new
    instance.GetPlayletLibUrls = __Http_PlayletLibUrlsRouter_method_GetPlayletLibUrls
    instance.ShowSetPlayletLibUrlsCode = __Http_PlayletLibUrlsRouter_method_ShowSetPlayletLibUrlsCode
    instance.SetPlayletLibUrls = __Http_PlayletLibUrlsRouter_method_SetPlayletLibUrls
    instance.DeletePlayletLibUrls = __Http_PlayletLibUrlsRouter_method_DeletePlayletLibUrls
    return instance
end function
function Http_PlayletLibUrlsRouter(server as object)
    instance = __Http_PlayletLibUrlsRouter_builder()
    instance.new(server)
    return instance
end function