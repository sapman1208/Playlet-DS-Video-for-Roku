function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    m.top.text = content.title
end function

function OnItemHasFocus()
    hasFocus = m.top.itemHasFocus
    if hasFocus
        m.top.font = "font:SmallestBoldSystemFont"
        m.top.color = "#262626ff"
    else
        m.top.font = "font:SmallestSystemFont"
        m.top.color = "#EBEBEBFF"
    end if
end function

function OnFocusPercent()
    if m.top.focusPercent > 0.5
        m.top.font = "font:SmallestBoldSystemFont"
        m.top.color = "#262626FF"
    else
        m.top.font = "font:SmallestSystemFont"
        m.top.color = "#EBEBEBFF"
    end if
end function