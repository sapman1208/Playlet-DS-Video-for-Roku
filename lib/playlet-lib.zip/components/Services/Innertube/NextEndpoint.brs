'import "pkg:/components/Services/Innertube/Context.bs"
'import "pkg:/components/Services/Innertube/Parser.bs"
'import "pkg:/components/Services/Innertube/protos/params.proto.gen.bs"
'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/ObjectUtils.bs"
'import "pkg:/source/utils/Types.bs"
function Innertube_CreateNextRequest(payloadArgs as object, options = invalid as object) as object
    deviceInfo = CreateObject("roDeviceInfo")
    context = Innertube_CreateContext("WEB", deviceInfo, options)
    payload = {
        "context": context
    }
    payload.Append(payloadArgs)
    request = HttpClient_Post("https://www.youtube.com/youtubei/v1/next?prettyPrint=false&alt=json").JsonBody(payload)
    request.Headers(Innertube_CreateHeaders("WEB"))
    return request
end function

function Innertube_GetEncodedNextParams(videoIds as object) as string
    if not IsArray(videoIds) or videoIds.Count() = 0
        return ""
    end if
    return Protobuf_Generated_misc_encodeNextParams({
        "video_id": videoIds
    })
end function

function Innertube_ParseInnertubeNextResponse(payload as object, parsedResponse as object, request as object) as object
    if not IsAssociativeArray(payload)
        LogWarn3("[NextEndpoint.bs:38]", "Invalid payload", payload)
        return parsedResponse
    end if
    playerOverlayRenderer = ObjectUtils_Dig(payload, [
        "playerOverlays"
        "playerOverlayRenderer"
    ])
    if not IsAssociativeArray(playerOverlayRenderer)
        LogWarn3("[NextEndpoint.bs:44]", "Invalid playerOverlayRenderer", playerOverlayRenderer)
        return parsedResponse
    end if
    endscreen = playerOverlayRenderer["endScreen"]
    feeds = Innertube_ParseResponseDataForFeeds(endscreen, {
        request: request
        noContainers: true
    })
    if feeds.Count() > 0
        parsedResponse["recommendedVideos"] = ValidArray(feeds[0].items)
    end if
    
    if parsedResponse.error <> invalid
        return parsedResponse
    end if
    if StringUtils_IsNullOrEmpty(parsedResponse.title)
        title = Innertube_ParseText(ObjectUtils_Dig(playerOverlayRenderer, [
            "videoDetails"
            "playerOverlayVideoDetailsRenderer"
            "title"
        ]))
        if not StringUtils_IsNullOrEmpty(title)
            parsedResponse.title = title
        end if
    end if
    if StringUtils_IsNullOrEmpty(parsedResponse.author)
        subtitle = Innertube_ParseText(ObjectUtils_Dig(playerOverlayRenderer, [
            "videoDetails"
            "playerOverlayVideoDetailsRenderer"
            "subtitle"
        ]))
        if not StringUtils_IsNullOrEmpty(subtitle)
            parsedResponse.author = subtitle
        end if
    end if
    return parsedResponse
end function