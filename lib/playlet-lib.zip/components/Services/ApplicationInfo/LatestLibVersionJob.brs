'import "pkg:/source/services/HttpClient.bs"
'import "pkg:/source/utils/CancellationUtils.bs"

function ExecuteJob() as void
    cancellation = JobGetCancellation()
    latest = GetLatestPlayletLibVersionFromGithubReleases(cancellation)
    JobSuccessData({
        latest: latest
    })
end function

function GetLatestPlayletLibVersionFromGithubReleases(cancellation as dynamic) as string
    response = HttpClient_Head("https://github.com/iBicha/playlet/releases/latest").Cancellation(cancellation).Await()
    if response.StatusCode() = 200
        headers = response.Headers()
        if headers.location <> invalid
            
            regex = CreateObject("roRegex", "\/v?(\d+\.\d+\.\d+)", "")
            match = regex.match(headers.location)
            if match.Count() = 2
                return match[1]
            end if
        end if
    end if
    return "N/A"
end function