'import "pkg:/source/services/HttpClient.bs"

' A fallback is needed to investigate https://github.com/iBicha/playlet/issues/906

function __Sentry_Delivery_method_new(events as object)
    m.events = invalid
    m.payload = invalid
    m.request = invalid
    m.pending = invalid
    m.sentToFallback = false
    m.events = events
    m.payload = Sentry_BuildEnvelope(events, false)
    m.Send("https://playlet-v8556.ondigitalocean.app/envelope", m.payload)
end function
function __Sentry_Delivery_method_Poll() as dynamic
    response = m.pending.Poll()
    if response = invalid
        return invalid
    end if
    
    if not m.sentToFallback and response.StatusCode() <= 0
        errorMessage = response.ErrorMessage()
        LogWarnNoTelemetry3("[Sentry.bs:31]", "Support server unreachable, sending events to the Sentry fallback:", errorMessage)
        m.sentToFallback = true
        unreachableEvent = Sentry_CreateSupportServerUnreachableEvent(m.events[0], m.payload, errorMessage)
        m.Send("https://o4509923566288896.ingest.us.sentry.io/api/4512194184544256/envelope/?sentry_key=a16c510299b23ccc63bdc84f751c9950", Sentry_BuildEnvelope([
            unreachableEvent
        ], true))
        return invalid
    end if
    if response.IsSuccess()
        
        return 0
    end if
    retryAfter = response.RetryAfterSeconds()
    if retryAfter = invalid or retryAfter = 0
        retryAfter = 60
    end if
    if response.StatusCode() = 429
        LogErrorNoTelemetry6("[Sentry.bs:49]", "Rate limited by", m.request.GetFullUrl(), "Retry after", retryAfter, "seconds")
    else
        LogErrorNoTelemetry7("[Sentry.bs:51]", "Failed to send events to", m.request.GetFullUrl(), response.ErrorMessage(), (chr(10) + "Retry after"), retryAfter, "seconds")
    end if
    return retryAfter
end function
function __Sentry_Delivery_method_Send(url as string, envelope as string) as void
    m.request = HttpClient_Post(url).TextBody(envelope).Header("Content-Type", "application/x-sentry-envelope")
    m.pending = m.request.Send()
end function
function __Sentry_Delivery_builder()
    instance = {}
    instance.new = __Sentry_Delivery_method_new
    ' invalid while it is being sent; then how long to hold events back, in seconds: 0 once delivered.
    instance.Poll = __Sentry_Delivery_method_Poll
    instance.Send = __Sentry_Delivery_method_Send
    return instance
end function
function Sentry_Delivery(events as object)
    instance = __Sentry_Delivery_builder()
    instance.new(events)
    return instance
end function

function Sentry_CreateSupportServerUnreachableEvent(originalEvent as object, payload as string, errorMessage as string) as object
    return {
        level: "warning"
        message: ("Support server unreachable: " + bslib_toString(errorMessage))
        fingerprint: [
            "support server unreachable"
        ]
        release: originalEvent.release
        tags: originalEvent.tags
        userId: originalEvent.userId
        attachments: [
            {
                filename: "envelope.txt"
                content_type: "text/plain"
                data: payload
            }
        ]
    }
end function

function Sentry_BuildEnvelope(events as object, supportsAttachments as boolean) as string
    timestamp = CreateObject("roDateTime").ToISOString()
    payload = FormatJson({
        sent_at: timestamp
        sdk: {
            name: "sentry.roku.playlet"
            version: "1.0.0"
        }
    }) + (chr(10))
    for each event in events
        payload += ("{" + chr(34) + "type" + chr(34) + ":" + chr(34) + "event" + chr(34) + "}") + (chr(10))
        if StringUtils_IsNullOrEmpty(event.event_id)
            event.event_id = m.deviceInfo.GetRandomUUID().Replace("-", "")
        end if
        if StringUtils_IsNullOrEmpty(event.timestamp)
            event.timestamp = timestamp
        end if
        eventPayload = {
            event_id: event.event_id
            timestamp: event.timestamp
            platform: "roku"
            environment: "production"
            release: event.release
            tags: event.tags
            level: event.level
            user: {
                id: event.userId
            }
        }
        message = Sentry_Redact(event.message)
        if event.fingerprint = invalid
            event.fingerprint = Sentry_GetFingerprint(message)
        end if
        if event.fingerprint <> invalid
            fingerprint = event.fingerprint
            if not IsArray(fingerprint)
                fingerprint = [
                    fingerprint
                ]
            end if
            for i = 0 to fingerprint.Count() - 1
                if not IsString(fingerprint[i])
                    fingerprint[i] = ToString(fingerprint[i])
                end if
            end for
            eventPayload.fingerprint = fingerprint
        end if
        hasAttachments = IsArray(event.attachments) and event.attachments.Count() > 0
        if (not supportsAttachments) and hasAttachments
            extra = {}
            for each attachment in event.attachments
                extra[attachment.filename] = ("content_type:" + bslib_toString(attachment.content_type) + chr(10) + bslib_toString(Sentry_Redact(attachment.data)))
            end for
            eventPayload.extra = extra
        end if
        eventPayload.logentry = {
            formatted: message
        }
        payload += FormatJson(eventPayload) + (chr(10))
        if supportsAttachments and hasAttachments
            tmpBuffer = CreateObject("roByteArray")
            for each attachment in event.attachments
                data = Sentry_Redact(attachment.data)
                attachment.Delete("data")
                attachment["type"] = "attachment"
                tmpBuffer.FromAsciiString(data)
                attachment["length"] = tmpBuffer.Count()
                payload += FormatJson(attachment) + (chr(10))
                payload += data + (chr(10))
            end for
        end if
    end for
    return payload
end function

function Sentry_GetFingerprint(message as dynamic) as dynamic
    if StringUtils_IsNullOrEmpty(message)
        return invalid
    end if
    
    fingerprint = Sentry_ReplaceRequestId(message)
    if fingerprint = invalid
        return invalid
    end if
    return [
        fingerprint
    ]
end function

function Sentry_ReplaceRequestId(message as string) as dynamic
    requestIdRegex = m.requestIdRegex
    if requestIdRegex = invalid
        requestIdRegex = CreateObject("roRegex", "RequestId:\s*[0-9]+", "")
        m.requestIdRegex = requestIdRegex
    end if
    matches = requestIdRegex.MatchAll(message)
    if not IsArray(matches) or matches.Count() = 0
        return invalid
    end if
    for each match in matches
        fullMatch = match[0]
        message = message.Replace(fullMatch, "RequestId: <REQUEST_ID>")
    end for
    return message
end function

function Sentry_Redact(text as dynamic) as dynamic
    if StringUtils_IsNullOrEmpty(text)
        return text
    end if
    authHeader = CreateObject("roRegex", "Authorization: (?!<REDACTED>)[^\r\n]*", "i")
    for each match in authHeader.MatchAll(text)
        text = text.Replace(match[0], "Authorization: <REDACTED>")
    end for
    refreshToken = CreateObject("roRegex", "(" + chr(34) + "refresh_token" + chr(34) + "\s*:\s*)" + chr(34) + "[^" + chr(34) + "]*" + chr(34) + "", "i")
    for each match in refreshToken.MatchAll(text)
        text = text.Replace(match[0], (bslib_toString(match[1]) + chr(34) + "<REDACTED>" + chr(34)))
    end for
    return text
end function