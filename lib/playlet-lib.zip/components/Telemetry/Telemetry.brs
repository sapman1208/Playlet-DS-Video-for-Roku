'import "pkg:/components/Telemetry/LastExitCrash.bs"
'import "pkg:/components/Telemetry/Sentry.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/Types.bs"


' A batch is sent once it holds MAX_EVENTS_PER_DELIVERY events, once no event came for BATCH_IDLE_MS, or BATCH_MAX_AGE_MS after the inbox was last empty.



function Init() as void
    InitializeBindings() ' auto-generated!
    if m.global.telemetry <> invalid
        return
    end if
    m.global.addFields({
        telemetry: m.top
    })
    m.top.functionName = "TelemetryLoop"
end function

function OnNodeReady() as void
    m.top.ObserveField("enabled", FuncName(OnEnabledChanged))
    m.preferences.ObserveFieldScoped("dev.diagnostics.enabled", FuncName(OnPreferencesChanged))
    enabled = ValidBool(m.preferences["dev.diagnostics.enabled"])
    OnPreferencesChanged({
        enabled: enabled
        getData: function() as boolean
            return m.enabled
        end function
    })
end function

function OnPreferencesChanged(event as object) as void
    m.top.enabled = event.getData()
end function

function OnEnabledChanged(event as object) as void
    enabled = event.getData()
    LogInfo3("[Telemetry.bs:37]", "Telemetry enabled:", enabled)
    if enabled
        m.top.control = "run"
    else
        m.top.control = "stop"
    end if
end function

function TelemetryLoop() as void
    msgPort = CreateObject("roMessagePort")
    m.deviceInfo = CreateObject("roDeviceInfo")
    m.tags = GetTags()
    m.release = GetRelease(m.tags)
    m.dist = GetDist(m.tags)
    m.userId = GetUserId()
    m.top.observeField("LogInfo", msgPort)
    m.top.observeField("LogWarn", msgPort)
    m.top.observeField("LogError", msgPort)
    m.top.observeField("LogEvent", msgPort)
    retryAfter = 0
    retryAfterTimer = CreateObject("roTimeSpan")
    delivery = Sentry_Delivery(CreateLaunchEvents())
    levelMap = {
        "LogInfo": "info"
        "LogWarn": "warning"
        "LogError": "error"
    }
    receivedAt = CreateObject("roDateTime")
    lastEventTimer = CreateObject("roTimeSpan")
    batchTimer = CreateObject("roTimeSpan")
    inbox = []
    while true
        waitMs = 0
        if delivery <> invalid
            waitMs = 500
        else if inbox.Count() > 0
            waitMs = 2000 - lastEventTimer.TotalMilliseconds()
            batchAgeLeftMs = 5000 - batchTimer.TotalMilliseconds()
            if batchAgeLeftMs < waitMs
                waitMs = batchAgeLeftMs
            end if
            
            if waitMs < 1
                waitMs = 1
            end if
        end if
        msg = wait(waitMs, msgPort)
        if delivery <> invalid
            deliveryRetryAfter = delivery.Poll()
            if deliveryRetryAfter <> invalid
                delivery = invalid
                retryAfter = deliveryRetryAfter
                if retryAfter > 0
                    retryAfterTimer.Mark()
                    inbox.Clear()
                end if
            end if
        end if
        if retryAfter > 0 and retryAfterTimer.TotalMilliseconds() < retryAfter * 1000
            continue while
        end if
        if msg <> invalid
            receivedAt.Mark()
            inbox.Push({
                msg: msg
                timestamp: receivedAt.ToISOString()
            })
            lastEventTimer.Mark()
            if inbox.Count() = 1
                batchTimer.Mark()
            end if
        end if
        if delivery <> invalid or inbox.Count() = 0
            continue while
        end if
        if inbox.Count() < 20 and lastEventTimer.TotalMilliseconds() < 2000 and batchTimer.TotalMilliseconds() < 5000
            continue while
        end if
        events = []
        while events.Count() < 20 and inbox.Count() > 0
            item = inbox.Shift()
            msg = item.msg
            msgType = type(msg)
            if msgType <> "roSGNodeEvent"
                continue while
            end if
            field = msg.getField()
            if levelMap.DoesExist(field)
                events.Push({
                    level: levelMap[field]
                    message: msg.getData()
                    timestamp: item.timestamp
                    release: m.release
                    dist: m.dist
                    tags: m.tags
                    userId: m.userId
                })
            else if field = "LogEvent"
                data = msg.getData()
                events.Push({
                    level: data.level
                    message: data.message
                    timestamp: item.timestamp
                    release: m.release
                    dist: m.dist
                    tags: m.tags
                    userId: m.userId
                    fingerprint: data.fingerprint
                    attachments: data.attachments
                })
            end if
        end while
        if events.Count() = 0
            continue while
        end if
        delivery = Sentry_Delivery(events)
    end while
end function

function CreateLaunchEvents() as object
    events = [
        {
            level: "info"
            message: "[SESSION] start"
            fingerprint: [
                "session start"
            ]
            release: m.release
            dist: m.dist
            tags: m.tags
            userId: m.userId
        }
    ]
    lastExitCrashEvent = CreateLastExitCrashEvent()
    if lastExitCrashEvent <> invalid
        events.Push(lastExitCrashEvent)
    end if
    return events
end function

function GetTags() as object
    appInfo = m.applicationInfo
    tags = appInfo.callfunc("GetAppInfo", invalid)
    tags.Append(appInfo.callfunc("GetDeviceInfo", invalid))
    tags.Delete("friendly_name")
    for each key in tags
        if not IsString(tags[key])
            tags[key] = ToString(tags[key])
        end if
    end for
    
    tags["session_id"] = m.deviceInfo.GetRandomUUID()
    return tags
end function

function GetRelease(tags as object) as string
    return (bslib_toString(tags["lib_version"]) + "-" + bslib_toString(tags["lib_git_commit_hash"]))
end function

function GetDist(tags as object) as string
    dist = (bslib_toString(tags["app_version"]) + "-" + bslib_toString(tags["app_git_commit_hash"]) + "-" + bslib_toString(tags["lib_version"]) + "-" + bslib_toString(tags["lib_git_commit_hash"]))
    if tags["id"] = "dev"
        dist = dist + "-dev"
    end if
    return dist
end function

function GetUserId() as string
    return CreateObject("roDeviceInfo").GetChannelClientId()
end function