sub init()
    m.top.observeField("buttonSelected", "onExitChoice")
end sub

sub onExitChoice(event as object)
    if event.getData() = 0
        m.top.confirmed = true
    else
        m.top.close = true
    end if
end sub
