'import "pkg:/components/ChannelView/ChannelUtils.bs"
'import "pkg:/components/ContextMenu/ContextMenuUtils.bs"
'import "pkg:/components/JobSystem/Jobs.bs"
'import "pkg:/components/JobSystem/JobSystem.bs"
'import "pkg:/components/Navigation/LongPress.bs"
'import "pkg:/components/PlaylistView/PlaylistUtils.bs"
'import "pkg:/components/Services/Invidious/InvidiousToContentNode.bs"
'import "pkg:/components/VideoFeed/FeedLoadState.bs"
'import "pkg:/source/utils/DisposableObserve.bs"
'import "pkg:/source/utils/ErrorUtils.bs"
'import "pkg:/source/utils/Logging.bs"
'import "pkg:/source/utils/RemoteKeys.bs"
'import "pkg:/source/utils/Types.bs"

' TODO:P1 add the option to remove a row if it does not have any content
' E.g. Subscriptions, Watch History and Playlists can be empty
function Init()
    InitializeBindings() ' auto-generated!
    m.pendingLoadJobs = {}
end function

function OnNodeReady()
    DisposableObserveField(m.top, "itemFocused", FuncName(OnItemFocused))
    DisposableObserveField(m.top, "rowItemFocused", FuncName(OnRowItemFocused))
    DisposableObserveField(m.top, "rowItemSelected", FuncName(OnRealRowItemSelected))
    DisposableObserveField(m.top, "focusedChild", FuncName(OnFocusedChildChange))
    DisposableObserveField(m.top, "visible", FuncName(OnVisibilityChange))
    
    DisposableObserveFieldScoped(m.profilesService, "currentProfileChanged", FuncName(OnCurrentProfileChanged))
    InitializeLongPress([
        "OK"
    ])
end function

function OnFocusedChildChange() as void
    if m.top.hasFocus()
        LoadRowsIfNeeded()
    end if
end function

function OnVisibilityChange()
    if m.top.visible = true
        LoadRowsIfNeeded()
    end if
end function

function OnFeedsChange() as void
    InitContent()
end function

function OnItemFocused()
    LoadRowsIfNeeded()
end function

function OnRowItemFocused(event as object) as void
    index = event.GetData()
    if index = invalid or index.count() <> 2
        LogWarn3("[VideoRowList.bs:55]", "Invalid index:", index)
        return
    end if
    rowIndex = index[0]
    rowItemIndex = index[1]
    row = m.top.content.GetChild(rowIndex)
    if not row.loadState = "LoadedPage"
        return
    end if
    
    if rowItemIndex > row.getChildCount() - 5
        LoadRowContent(row)
    end if
end function

function OnRowItemSelected(index as object) as void
    content = m.top.content
    if content = invalid
        return
    end if
    if index = invalid or index.count() <> 2
        LogWarn3("[VideoRowList.bs:79]", "Invalid index:", index)
        return
    end if
    rowIndex = index[0]
    rowItemIndex = index[1]
    if rowIndex < 0 or rowIndex >= content.GetChildCount()
        LogWarn3("[VideoRowList.bs:87]", "Invalid row index:", rowIndex)
        return
    end if
    row = content.GetChild(rowIndex)
    if rowItemIndex < 0 or rowItemIndex >= row.GetChildCount()
        LogWarn3("[VideoRowList.bs:93]", "Invalid row item index:", rowItemIndex)
        return
    end if
    rowItem = row.GetChild(rowItemIndex)
    if rowItem.type = "video"
        videoId = rowItem.videoId
        LogInfo2("[VideoRowList.bs:100]", "Play video: " + videoId)
        m.videoQueue.playVideo = rowItem
    else if rowItem.type = "playlist"
        playlistId = rowItem.playlistId
        LogInfo2("[VideoRowList.bs:104]", "Open playlist: " + playlistId)
        OpenPlaylist(rowItem)
    else if rowItem.type = "channel"
        authorId = rowItem.authorId
        LogInfo2("[VideoRowList.bs:108]", "Open channel: " + authorId)
        OpenChannel(rowItem)
    else
        LogWarnNoTelemetry3("[VideoRowList.bs:111]", "Unknown row item type:", rowItem.type)
    end if
end function

function OnRowItemLongPressed(index as object) as void
    content = m.top.content
    if content = invalid
        return
    end if
    if not IsArray(index) or index.count() <> 2
        LogWarn3("[VideoRowList.bs:122]", "Invalid index:", index)
        return
    end if
    rowIndex = index[0]
    rowItemIndex = index[1]
    if not IsInt(rowIndex) or rowIndex < 0 or rowIndex >= content.GetChildCount()
        LogWarn3("[VideoRowList.bs:130]", "Invalid row index:", rowIndex)
        return
    end if
    row = content.GetChild(rowIndex)
    if not IsInt(rowItemIndex) or rowItemIndex < 0 or rowItemIndex >= row.GetChildCount()
        LogWarn3("[VideoRowList.bs:136]", "Invalid row item index:", rowItemIndex)
        return
    end if
    rowItem = row.GetChild(rowItemIndex)
    contextMenuProviders = [
        m.top
        m.bookmarksService
        m.top.screen
    ]
    ContextMenuUtils_Open(contextMenuProviders, m.appController, rowItem)
end function

function GetContextMenuOptionsForItem(rowItem as object) as object
    options = []
    if rowItem.type = "video"
        options.push(ContextMenuUtils_CreateOption(Tr("Play Video"), m.videoQueue, "FuncPlayVideo", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Queue Video"), m.videoQueue, "FuncAddToQueueVideo", [
            rowItem
        ]))
        authorId = rowItem.authorId
        if not StringUtils_IsNullOrEmpty(authorId)
            options.push(ContextMenuUtils_CreateOption(Tr("Open Channel"), m.top, "OpenVideoChannel", [
                rowItem
            ]))
        end if
    else if rowItem.type = "playlist"
        options.push(ContextMenuUtils_CreateOption(Tr("Play Playlist"), m.videoQueue, "FuncPlayPlaylist", [
            rowItem
            0
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Queue Playlist"), m.videoQueue, "FuncAddToQueuePlaylist", [
            rowItem
        ]))
        options.push(ContextMenuUtils_CreateOption(Tr("Open Playlist"), m.top, "OpenPlaylist", [
            rowItem
        ]))
        authorId = rowItem.authorId
        if not StringUtils_IsNullOrEmpty(authorId)
            options.push(ContextMenuUtils_CreateOption(Tr("Open Channel"), m.top, "OpenPlaylistChannel", [
                rowItem
            ]))
        end if
    else if rowItem.type = "channel"
        options.push(ContextMenuUtils_CreateOption(Tr("Open Channel"), m.top, "OpenChannel", [
            rowItem
        ]))
    else
        LogWarnNoTelemetry3("[VideoRowList.bs:169]", "Unknown long pressed item type:", rowItem.type)
        return []
    end if
    return options
end function

function OpenPlaylist(playlist as object)
    PlaylistUtils_Open(playlist)
end function

function OpenChannel(channel as object)
    ChannelUtils_Open(channel)
end function

function OpenVideoChannel(video as object) as void
    authorId = video.authorId
    if StringUtils_IsNullOrEmpty(authorId)
        LogWarn3("[VideoRowList.bs:187]", "Invalid authorId:", authorId)
        return
    end if
    channel = InvidiousContent_ToChannelContentNode(invalid, {
        authorId: authorId
    })
    ChannelUtils_Open(channel)
end function

function OpenPlaylistChannel(playlist as object) as void
    authorId = playlist.authorId
    if StringUtils_IsNullOrEmpty(authorId)
        LogWarn3("[VideoRowList.bs:197]", "Invalid authorId:", authorId)
        return
    end if
    channel = InvidiousContent_ToChannelContentNode(invalid, {
        authorId: authorId
    })
    ChannelUtils_Open(channel)
end function

function Refresh(_unused as dynamic)
    InitContent()
end function

function OnCurrentProfileChanged()
    
    InitContent()
end function

function InitContent() as void
    CancelCurrentJobs()
    if m.top.feeds = invalid
        m.top.content = invalid
        return
    end if
    input = {
        node: m.top
        feeds: m.top.feeds
    }
    callback = JobSystem_CreateCallback(OnVideoRowListContentJobDone)
    m.pendingLoadJobs[callback.id] = {
        callback: callback
    }
    JobSystem_QueueJob(m.jobQueue, "VideoRowListContentJob", input, callback)
end function

function CancelCurrentJobs()
    pendingLoadJobs = m.pendingLoadJobs
    for each id in pendingLoadJobs
        callback = pendingLoadJobs[id].callback
        callback.cancel = true
    end for
    m.pendingLoadJobs = {}
end function

function OnVideoRowListContentJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.pendingLoadJobs.Delete(event.getNode())
    info = event.getInfo()
    if info.cancel
        return
    end if
    LoadRowsIfNeeded()
end function

function LoadRowsIfNeeded() as void
    if m.top.content = invalid or not m.top.visible
        return
    end if
    itemsToLoad = GetRowsToLoad()
    for each item in itemsToLoad
        LoadRowContent(item)
    end for
end function

function GetRowsToLoad() as object
    focus = m.top.itemFocused
    if focus = -1
        focus = 0
    end if
    contentNode = m.top.content
    rowCount = contentNode.getChildCount()
    if rowCount = 0
        return []
    end if
    subContentNodes = []
    range = m.top.numRows + 1
    for i = -range to range
        index = focus + i
        if index < 0
            continue for
        end if
        if index >= rowCount
            continue for
        end if
        subContentNode = contentNode.getChild(index)
        if subContentNode.loadState <> "None"
            continue for
        end if
        subContentNodes.push(subContentNode)
    end for
    return subContentNodes
end function

function LoadRowContent(contentNode as object) as void
    
    for each id in m.pendingLoadJobs
        job = m.pendingLoadJobs[id]
        if contentNode.isSameNode(job.content) and not job.callback.done
            LogInfo3("[VideoRowList.bs:301]", "Row content already loading:", contentNode.title)
            return
        end if
    end for
    LogInfo3("[VideoRowList.bs:306]", "Loading row content:", contentNode.title)
    contentNode.loadState = "Loading"
    input = {
        rowList: m.top
        feedContentNode: contentNode
        invidious: m.invidious
    }
    callback = JobSystem_CreateCallback(OnVideoRowListRowContentJobDone)
    m.pendingLoadJobs[callback.id] = {
        callback: callback
        content: contentNode
    }
    JobSystem_QueueJob(m.jobQueue, "VideoRowListRowContentJob", input, callback)
end function

function OnVideoRowListRowContentJobDone(event as object) as void
    JobSystem_UnobserveCallback(event.getRoSGNode())
    m.pendingLoadJobs.Delete(event.getNode())
    info = event.getInfo()
    if info.cancel
        return
    end if
    LoadRowsIfNeeded()
end function

function OnRealRowItemSelected()
    
    LongPressHandler("OK", true)
end function

function OnKeyEvent(key as string, press as boolean) as boolean
    
    if not (key = "OK" and press)
        if LongPressHandler(key, press)
            return true
        end if
    end if
    if key = "OK_LONG_PRESS" and press
        OnRowItemLongPressed(m.top.rowItemFocused)
        return true
    end if
    if key = "OK" and not press
        
        OnRowItemSelected(m.top.rowItemSelected)
        return true
    end if
    return false
end function

function OnDispose()
    CancelCurrentJobs()
    DisposeObservers()
    m.top.screen = invalid
    m.top.content = invalid
    m.top.itemComponentName = invalid
end function