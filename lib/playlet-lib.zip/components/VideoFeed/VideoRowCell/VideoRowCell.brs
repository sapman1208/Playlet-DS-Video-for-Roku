'import "pkg:/source/utils/Locale.bs"
'import "pkg:/source/utils/MathUtils.bs"
'import "pkg:/source/utils/StringUtils.bs"
'import "pkg:/source/utils/TimeUtils.bs"
'import "pkg:/source/utils/Types.bs"

function Init()
    m.durationRect = m.top.FindNode("durationRect")
    m.durationLabel = m.top.FindNode("durationLabel")
    m.smallestSystemFont = m.top.FindNode("smallestSystemFont")
    m.smallestBoldSystemFont = m.top.FindNode("smallestBoldSystemFont")
    m.progressRect = m.top.FindNode("progressRect")
end function

function OnContentSet() as void
    content = m.top.itemContent
    if content = invalid
        return
    end if
    m.top.title = content.title
    lines = content.lines
    
    author = content._author
    if StringUtils_IsNullOrEmpty(author)
        if IsArray(lines) and lines.Count() > 0
            author = lines[0]
        end if
    end if
    m.top.author = author
    viewCountDate = ""
    if content.isUpcoming = true
        viewCountDate = content.premiereTimestampText
    else
        publishedText = content.publishedText
        viewCountText = content.viewCountText
        label = publishedText
        if publishedText.Len() > 0 and viewCountText.Len() > 0
            label += " • "
        end if
        label += viewCountText
        viewCountDate = label
    end if
    if StringUtils_IsNullOrEmpty(viewCountDate)
        if IsArray(lines) and lines.Count() > 1
            viewCountDate = lines[1]
        end if
    end if
    m.top.viewCountDate = viewCountDate
    m.top.thumbnailUri = content.thumbnail
    m.top.percentDurationWatched = content.percentDurationWatched
    if not StringUtils_IsNullOrEmpty(content.lengthText)
        SetDurationLabel(content.lengthText, "#161616FF", 0.8, m.smallestSystemFont)
        m.top.durationRectVisible = true
    else
        if content.isUpcoming = true
            SetDurationLabel(Tr("UPCOMING"), "#161616FF", 0.8, m.smallestBoldSystemFont)
            m.top.durationRectVisible = true
        else if content.liveNow
            SetDurationLabel(Tr("LIVE"), "#CC0000FF", 0.9, m.smallestBoldSystemFont)
            m.top.durationRectVisible = true
        else
            m.top.durationRectVisible = false
        end if
    end if
end function

function SetDurationLabel(text as string, bgColor as string, bgOpacity as float, font as object) as void
    m.top.duration = text
    label = m.durationLabel
    rect = m.durationRect
    if label = invalid or rect = invalid
        return
    end if
    rectParent = rect.getParent()
    label.font = font
    size = label.localBoundingRect()
    rect.width = size.width + 16
    rect.translation = [
        rectParent.width - rect.width
        rect.translation[1]
    ]
    rect.color = bgColor
    rect.opacity = bgOpacity
end function

function OnPercentDurationWatched() as void
    if m.progressRect = invalid
        return
    end if
    percent = MathUtils_Clamp(m.top.percentDurationWatched, 0, 100) / 100.0
    m.progressRect.scale = [
        percent
        1
    ]
end function